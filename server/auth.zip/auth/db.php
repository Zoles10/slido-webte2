<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);


$servername = 
$username = 
$password = 
$database = 

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['error' => $conn->connect_error]));
}
?>
